from test.libregrtest.main import main
main(_add_python_opts=True)
