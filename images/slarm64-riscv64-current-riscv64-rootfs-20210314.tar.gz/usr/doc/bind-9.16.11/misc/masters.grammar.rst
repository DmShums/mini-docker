::

  masters <string> [ port <integer> ] [ dscp
      <integer> ] { ( <masters> | <ipv4_address> [
      port <integer> ] | <ipv6_address> [ port
      <integer> ] ) [ key <string> ]; ... };
