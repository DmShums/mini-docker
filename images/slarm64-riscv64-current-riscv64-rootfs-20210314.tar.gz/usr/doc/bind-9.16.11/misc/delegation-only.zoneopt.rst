::

  zone <string> [ <class> ] {
  	type delegation-only;
  };
