::

  zone <string> [ <class> ] {
  	type hint;
  	check-names ( fail | warn | ignore );
  	delegation-only <boolean>;
  	file <quoted_string>;
  };
