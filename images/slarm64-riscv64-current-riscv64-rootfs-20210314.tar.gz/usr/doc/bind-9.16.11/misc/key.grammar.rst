::

  key <string> {
  	algorithm <string>;
  	secret <string>;
  };
