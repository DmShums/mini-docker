::

  trusted-keys { <string> <integer>
      <integer> <integer>
      <quoted_string>; ... };, deprecated
