::

  managed-keys { <string> ( static-key
      | initial-key | static-ds |
      initial-ds ) <integer> <integer>
      <integer> <quoted_string>; ... };, deprecated
