::

  zone <string> [ <class> ] {
  	in-view <string>;
  };
