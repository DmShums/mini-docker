[![GitHub Build Status](https://github.com/inotify-tools/inotify-tools/workflows/build/badge.svg)](https://github.com/inotify-tools/inotify-tools/actions)
[![Travis Build Status](https://travis-ci.org/inotify-tools/inotify-tools.svg?branch=master)](https://travis-ci.org/inotify-tools/inotify-tools)
[![Cirrus Build Status](https://api.cirrus-ci.com/github/inotify-tools/inotify-tools.svg?branch=master)](https://cirrus-ci.com/github/inotify-tools/inotify-tools)
[![Language Grade: C/C++](https://img.shields.io/lgtm/grade/cpp/g/inotify-tools/inotify-tools.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/inotify-tools/inotify-tools/context:cpp)

inotify-tools
=============

This is a package of some commandline utilities relating to inotify.

The general purpose of this package is to allow inotify's features to be used
from within shell scripts.  Read the man pages for further details.

