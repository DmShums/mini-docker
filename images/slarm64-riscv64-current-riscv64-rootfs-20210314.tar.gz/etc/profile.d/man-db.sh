#!/bin/sh
# Choose a default for the system's manual pager:
#export MANPAGER=less
#export MANPAGER=more
#export MANPAGER=most
