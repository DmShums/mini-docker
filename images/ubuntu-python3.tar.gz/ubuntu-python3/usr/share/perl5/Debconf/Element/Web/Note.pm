#!/usr/bin/perl
# This file was preprocessed, do not edit!


package Debconf::Element::Web::Note;
use warnings;
use strict;
use base qw(Debconf::Element::Web::Text);


1
